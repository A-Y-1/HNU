#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include "com.h"
#include "com.c"
unsigned char func(unsigned char a);
int main(void)
{
	unsigned char tmp[20]; //用于存放读取出来的数据的缓冲区
	int rl; //读取数据的长度（单位：字节）
	int i;
 
	fd = openSerial("/dev/ttyS1"); //打开串口，ttyUSB0是串口文件,在我的虚拟机上是ttyS1，根据你的虚拟机串口修改！！！！！！！！！！！！！！
	
	if(fd < 0)
	{
		printf("open com fail!\n");
		return 0;
	}
	
	EpollInit(fd); //初始化终端事件触发函数epoll,设置要监听的事件及相关参数等
	
	unsigned char buf[]={0xAA,0x55,};	//你的学号！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
	if(write(fd,buf,14)<=0) printf("write failed!\n");
	int count=0;
	int start=1000;
	unsigned char temp; 
	
	while(1){
		//bzero(tmp,sizeof(tmp)); 				//置零
		rl = ComRead(tmp,20);					//读取数据,读到足够多
		if(rl<6) continue;
		//输出读到的内容
		printf("读取数据：");
		for(i = 0; i < rl; i++)
			printf(" %02x", tmp[i]);
		printf("\n");
		//取出密码
		start = tmp[2];
		for(i=2;i<6;i++){
			buf[i] = tmp[(int)tmp[2]-3+i];
		}
		printf("密码为：");
		for(i=2;i<6;i++){
			printf(" %02x", buf[i]);
		}
		printf("\n\n");
		if(write(fd, buf, 6) <= 0)
      			printf("Write Failed!\n");
	}
	close(epid);
	close(fd);
	return 0;
}


